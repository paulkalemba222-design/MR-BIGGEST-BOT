# Commandes désactivées

Placez ici les fichiers `.js` des commandes que vous ne voulez pas charger.
Le bot ne charge automatiquement que les fichiers `.js` de `worker/commands/`.
