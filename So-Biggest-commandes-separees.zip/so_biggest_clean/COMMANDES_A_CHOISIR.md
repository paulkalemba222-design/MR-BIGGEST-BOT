# 🦁 So Biggest — Commandes disponibles

Chaque commande est un fichier `.js` indépendant dans `worker/commands/`.

## Comment sélectionner les commandes
1. Garde les fichiers `.js` que tu veux dans `worker/commands/`.
2. Pour désactiver une commande, déplace simplement son fichier dans `worker/commands_disabled/` (ce dossier n’est pas chargé par le bot).
3. Pour la réactiver, remets le fichier dans `worker/commands/`.
4. Le bot charge automatiquement tous les `.js` présents dans `worker/commands/`.

## 📋 Général

- [ ] `menu` — `menu.js`
- [ ] `ping` — `ping.js`
- [ ] `owner` — `owner.js`
- [ ] `infos` — `infos.js`
- [ ] `whois` — `whois.js`
- [ ] `device` — `device.js`
- [ ] `vv` — `vv.js`
- [ ] `delete` — `delete.js`
- [ ] `photo` — `photo.js`
- [ ] `principal` — `principal.js`

## 👥 Groupe

- [ ] `add` — `add.js`
- [ ] `kick` — `kick.js`
- [ ] `kickall` — `kickall.js`
- [ ] `promote` — `promote.js`
- [ ] `promoteall` — `promoteall.js`
- [ ] `demote` — `demote.js`
- [ ] `demoteall` — `demoteall.js`
- [ ] `tag` — `tag.js`
- [ ] `tagall` — `tagall.js`
- [ ] `tagadmin` — `tagadmin.js`
- [ ] `infosgroups` — `infosgroups.js`
- [ ] `gclink` — `gclink.js`
- [ ] `left` — `left.js`
- [ ] `listonline` — `listonline.js`
- [ ] `mute` — `mute.js`
- [ ] `unmute` — `unmute.js`
- [ ] `mute-time` — `mute-time.js`

## 🛡️ Sécurité

- [ ] `antilink` — `antilink.js`
- [ ] `antibot` — `antibot.js`
- [ ] `antispam` — `antispam.js`
- [ ] `antipromote` — `antipromote.js`
- [ ] `antidemote` — `antidemote.js`
- [ ] `warnadmin` — `warnadmin.js`

## 👑 Sudo / administration

- [ ] `setsudo` — `setsudo.js`
- [ ] `delsudo` — `delsudo.js`
- [ ] `listsudo` — `listsudo.js`
- [ ] `setpp` — `setpp.js`
- [ ] `setppg` — `setppg.js`
- [ ] `save` — `save.js`
- [ ] `writetoall` — `writetoall.js`
- [ ] `settimeg` — `settimeg.js`

## 🎵 Téléchargement / média

- [ ] `url` — `url.js`
- [ ] `sticker` — `sticker.js`
- [ ] `wasted` — `wasted.js`

## ⚙️ Autres

- [ ] `autojoin` — `autojoin.js`

## 🧩 Autres commandes

- [ ] `autorecording` — `autorecording.js`
- [ ] `purge` — `purge.js`

## ⚠️ Important
Le code d’origine contient encore des éléments liés à Cifer/Telegram. Ce ZIP est organisé pour la sélection des commandes ; l’identité complète So Biggest/Mr Biggest sera traitée séparément avant le déploiement final.
