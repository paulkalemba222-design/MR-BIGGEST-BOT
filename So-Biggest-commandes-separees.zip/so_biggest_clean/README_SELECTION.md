# 🦁 So Biggest — version commandes séparées

Cette archive est organisée pour que chaque commande WhatsApp soit un fichier JavaScript séparé.

## Où sont les commandes ?
`worker/commands/`

## Pour désactiver une commande
Déplacez son fichier `.js` vers :
`worker/commands_disabled/`

## Pour la réactiver
Remettez le fichier dans :
`worker/commands/`

## Liste complète
Consultez `COMMANDES_A_CHOISIR.md`.

## Déploiement
Le projet utilise un worker Node.js/WhatsApp. Vercel ne doit pas être utilisé comme processus WhatsApp permanent ; Render (ou un autre hébergeur de processus persistant) convient au worker.

⚠️ Avant le déploiement final, la configuration Cifer/Telegram et les informations d'identité devront être remplacées proprement par celles de So Biggest / Mr Biggest.
